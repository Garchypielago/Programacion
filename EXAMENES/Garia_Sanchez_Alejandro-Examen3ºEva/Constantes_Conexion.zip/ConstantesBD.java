package bbdd;

public class ConstantesBD {
	public static final String URL="jdbc:mysql://localhost/XXXX";
	public static final String USUARIO="root";
	public static final String PWD="";
}
