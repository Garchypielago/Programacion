package excepciones;

public class ErrorDuracion extends Exception {

	public ErrorDuracion() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ErrorDuracion(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
