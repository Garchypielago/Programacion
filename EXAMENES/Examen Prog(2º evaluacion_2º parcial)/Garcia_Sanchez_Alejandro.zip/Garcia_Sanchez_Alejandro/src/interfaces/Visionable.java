package interfaces;

public interface Visionable {
	
	public String Visionar() ;

}
