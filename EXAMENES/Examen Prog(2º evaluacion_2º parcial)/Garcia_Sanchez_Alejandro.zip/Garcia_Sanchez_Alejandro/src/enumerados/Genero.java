package enumerados;

public enum Genero {

	DRAMATICO, COMEDIA, ROMANTICO, THRILLER;
	
	
	
	
}
