package bufferedReader;

import java.io.*;

public class LeeTecladoLineas{
    public static void main(String arg[]){
    String mensaje;
		try { 
			BufferedReader entradaEstandar = new BufferedReader(new InputStreamReader(System.in));
			
			System.out.println ("Introducir una linea de texto:");
			mensaje = entradaEstandar.readLine();
			System.out.println ("Introducido: \"" + mensaje + "\"");
		} catch (IOException e) {
			System.out.println(e);
		}
		// Lo que se hace en este ejemplo es similar a usar la clase Scanner
	}
}
