package definicion;
// Interfaz que solo nos aporta una constante
public interface X {
	int MAX = 10; // Es public final static, aunque no lo ponga
}	
