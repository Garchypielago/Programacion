package pruebas;
public interface Figura{ 
	int area();
}
