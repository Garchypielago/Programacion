
package pruebas;
public interface MiInterfaz {
	int CONSTANTE = 100; // No puede ser ni privada ni protected, siempre public final y estatica

	int metodoAbstracto(int parametro); // No puede ser ni privada ni protected, es abstract y public
}
