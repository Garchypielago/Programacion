package bebidas;

enum MarcaCerveza {
	AMBAR, GUINNESS, HEINEKEN
};

