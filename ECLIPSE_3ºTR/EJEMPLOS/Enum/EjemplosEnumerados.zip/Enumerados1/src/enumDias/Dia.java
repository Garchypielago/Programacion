package enumDias;

//Una clase enum

public enum Dia {
	LUNES, MARTES, MIERCOLES, JUEVES, VIERNES, SABADO, DOMINGO;
}
