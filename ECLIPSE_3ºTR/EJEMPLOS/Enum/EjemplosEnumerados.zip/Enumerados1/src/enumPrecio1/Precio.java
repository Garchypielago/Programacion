package enumPrecio1;

// Aqui el enum funciona como un listado de constantes
public enum Precio {
	BARATO, MEDIO, CARO;

//  Se puede sobrescribir, pero la clase Enum ya lo tiene implementado
//	public String toString() {
//		return "soy un poco " + super.toString();
//	}
}
