package enumTransportes1;
//Una enumeracion de transporte

public enum Transporte{
  COCHE, CAMION, AVION, TREN, BARCO;
}