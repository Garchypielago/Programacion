package enumColores1;

public class Test
{

    public static void main(String[] args)
    {
        Color c1 = Color.ROJO;
        
        System.out.println(c1);
    }
}