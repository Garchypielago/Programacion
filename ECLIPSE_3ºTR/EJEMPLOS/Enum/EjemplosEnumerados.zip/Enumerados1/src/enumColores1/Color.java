package enumColores1;
// Un simple ejemplo donde se declara enum
// fuera de cualquier clase (Nota la palabra enum en lugar
// de la palabra class)
public enum Color
{
    ROJO, VERDE, AZUL;
}
