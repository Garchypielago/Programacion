package ordenacion;
public class Jugador {
	public String nombre;
    public int edad, altura;

    public Jugador(String nombre, int edad, int altura) {
        this.nombre = nombre;
        this.edad = edad;
        this.altura = altura;
    }

    @Override
    public String toString() {
        return "\n Jugador->  Nombre: "+nombre+ " Edad: " + edad + " Altura: " +altura+ "\n";}

    public int getEdad() {return edad;}
    public String getNombre() {return nombre;}
    public int getAltura() {return altura;}
}
