package registrado;

public class ConstantesBD {
	public static final String URL="";
	public static final String USUARIO="";
	public static final String PWD="";
}
