package ejemplo1;

@FunctionalInterface
public interface Calcular {
	Integer op(Integer a, Integer b);
// puede tener otros métodos de los permitidos
}
