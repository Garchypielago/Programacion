package dialogos;

import javax.swing.JOptionPane;

public class EjDialogo1 {

	public static void main(String[] args) {
		JOptionPane.showMessageDialog(null, "Hola Mundo");
	}

}
