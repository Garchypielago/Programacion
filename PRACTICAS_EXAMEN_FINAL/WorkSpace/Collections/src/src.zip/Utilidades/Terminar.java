package Utilidades;

public class Terminar extends Exception{

	public Terminar() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Terminar(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
