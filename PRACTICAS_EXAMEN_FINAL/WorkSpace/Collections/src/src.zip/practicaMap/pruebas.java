package practicaMap;

public class pruebas {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int ev = 2;

		if ((ev != 1 && ev != 2 && ev != 3)) {
			System.out.println("bien");
			//estaria l excepcion
		} else {
			System.out.println("mal");
			//
		}
		
	}

}
