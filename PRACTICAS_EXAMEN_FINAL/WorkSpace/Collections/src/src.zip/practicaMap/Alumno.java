package practicaMap;

public class Alumno {
	
	String nombre;
	int pev, sev, tev;
	
	public Alumno(String nombre) {
		super();
		this.nombre = nombre;
	}
	
	

	public Alumno(String nombre, int pev, int sev, int tev) {
		super();
		this.nombre = nombre;
		this.pev = pev;
		this.sev = sev;
		this.tev = tev;
	}



	public int getPev() {
		return pev;
	}

	public void setPev(int pev) {
		this.pev = pev;
	}

	public int getSev() {
		return sev;
	}

	public void setSev(int sev) {
		this.sev = sev;
	}

	public int getTev() {
		return tev;
	}

	public void setTev(int tev) {
		this.tev = tev;
	}

	public String getNombre() {
		return nombre;
	}

	@Override
	public String toString() {
		return "Alumno [nombre=" + nombre + ", pev=" + pev + ", sev=" + sev + ", tev=" + tev + "]";
	}
	
	
	
	
	
	
	

}
