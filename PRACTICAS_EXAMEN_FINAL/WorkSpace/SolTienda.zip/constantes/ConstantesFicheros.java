package constantes;
public class ConstantesFicheros {
	public final static String NOMFICHPROD = "productos.dat";
	public static final String NOMFICHVEND = "vendidos.txt";
}
