package constantes;
public class ConstantesBD {
	public static final String URL="jdbc:mysql://localhost/almacen";
	public static final String USUARIO="root";
	public static final String PWD="";
}
